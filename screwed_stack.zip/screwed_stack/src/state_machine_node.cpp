
#include <moveit/move_group_interface/move_group_interface.h>


int main(int argc, char** argv)
{
    ros::init(argc, argv, "state_machine_node");
    ros::NodeHandle nh;

    // Main Loop
    


    ros::spin();
    return 0;
}