// StateMachine.cpp

#include "StateMachine.hpp"
#include <iostream>


class Machine : public StateMachine {


}